<?php

namespace Conns\Yeslease\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action {


    public function execute()
    {

       echo "testing";
	   exit;
    }
}